package boomerangsearch.step1;

public class Step1SolutionTweakey {
  public int[][][] DTK;
  public int[] lanes;

  public Step1SolutionTweakey() {}

  public Step1SolutionTweakey(final int[][][] DTK, final int[] lanes) {
    this.DTK = DTK;
    this.lanes = lanes;
  }
}
